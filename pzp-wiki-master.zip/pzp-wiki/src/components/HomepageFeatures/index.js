import React from 'react';
import clsx from 'clsx';
import IconExternalLink from '@theme/Icon/ExternalLink';
import styles from './styles.module.css';

const FeatureList = [
  {
    title: 'Code',
    description: (
      <>
        PZP is not ready for end users yet but it's stable enough for developers to have a fun time hacking with/on it.
      </>
    ),
    link: 'https://codeberg.org/pzp',
  },
  {
    title: 'SDK',
    description: (
      <>
        We have a simple SDK that helps you get started making PZP apps.
      </>
    ),
    link: 'https://codeberg.org/pzp/pzp-sdk',
  },
  {
    title: 'Demo app',
    description: (
      <>
        A demo app demonstrating some PZP features. Take a look at the code for inspiration. Note that you probably have to be a developer to build and use it.
      </>
    ),
    link: 'https://codeberg.org/pzp/zooboard',
  },
];

function Feature({title, description, link}) {
  return (
    <div className={clsx('col col--4')}>
      <div className="text--center padding-horiz--md">
        <a href={link} target='_blank' style={{color: 'var(--ifm-font-color-base)'}}>
          <h3>{title}<IconExternalLink/></h3>
          <p>{description}</p>
        </a>
      </div>
    </div>
  );
}

export default function HomepageFeatures() {
  return (
    <section className={styles.features}>
      <div className="container">
        <div className="row">
          {FeatureList.map((props, idx) => (
            <Feature key={idx} {...props} />
          ))}
        </div>
      </div>
    </section>
  );
}
