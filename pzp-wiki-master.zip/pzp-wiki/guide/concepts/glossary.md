---
sidebar_position: 80
---

# Glossary

- **Msg** = published data that is signed and shareable
- **Msg hash** = hash(msg.metadata)
- **Tangle** = any single-root DAG of msgs that can be replicated by peers
- **Tangle Root** = the origin msg of a tangle
- **Tangle Affix** = any msg in a tangle that is not the root
- **Tangle Tips** = tangle msgs that are not yet referenced by any other msg in the tangle
- **Tangle ID** = Msg hash of the tangle's root msg
- **Account tangle** = tangle with msgs that add (or remove?) asymmetric-crypto public keys
- **Account ID** = tangle ID of the account tangle, refers to a person or a group
- **Moot** = the "virtual root" of a tangle. The moot is a msg that is deterministically predictable and empty, so to allow others to pre-know its hash. It never needs to be stored in disk nor transmitted via network, since it can be recreated on the fly
- **Feed** = tangle with msgs authored by (any pubkey in) an account under a certain "domain", beginning from a moot
- **Feed ID** = ID of a feed (Msg ID of the feed's moot)
