---
sidebar_position: 50
---

# Hub

:::note Definition
**A hub is a server that allow clients to communicate with each other via end-to-end encrypted tunnels. Hubs and clients form a fluid multi-star topology.**
:::