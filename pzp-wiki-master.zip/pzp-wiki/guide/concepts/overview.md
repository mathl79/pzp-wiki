---
sidebar_position: 0
---

# Overview

**In PZP, [peers](./peer) publish [messages](./message) on [feeds](./feed) that are [replicated](./replication) by other peers in a gossip network of [hubs](./hub). To join the network, a peer must be [invited](./invite).**
