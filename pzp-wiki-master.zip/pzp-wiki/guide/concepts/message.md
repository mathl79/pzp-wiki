---
sidebar_position: 20
---

# Message

:::note Definition
**A message is a JSON encoded data structure that is signed by a peer and intended for replication in a gossip network.**
:::

## Data

## Metadata

## Public key

## Signature
