---
sidebar_position: 10
---

# Peer

:::note Definition
**A peer is a participant in a gossip network, identified by a self-certifying cryptographic keypair.**
:::



## Keypair for SHSe

Asymmetric cryptographic keypair that identifies the current peer.
