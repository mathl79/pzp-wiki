---
sidebar_position: 1
---

# PZP Docs

What is "PZP":
- A [local-first][local-first] P2P protocol with 10 years of learnings baked in
- Message formats + Message validation + RPC methods
- If scuttlebutt is :slightly_smiling_face: then pzp is :sunglasses: 
- No apps so far except for a [demo app][zooboard], but it's ready for developers to have fun with and hack on.

## Features

- Peer to peer. PZP is designed in a way to avoid centralization of power.
- Low storage expectations. Expecting users to store large amounts of data makes adoption on phones and old devices hard, and eventually risks centralization and corporate takeover when only resource rich users or even companies have enough resources needed to keep the network running.
- Content/public-key adressed data. We try to avoid relying on DNS since that would put too much trust/pressure on single nodes.
- Easy to use CRDT data structures like sets and dicts.
- [Local-first][local-first]
- No DHTs or other [singletons](https://handbook.scuttlebutt.nz/stories/design-challenge-avoid-centralization-and-singletons).
- First class multi-device and multi-app support. A user's account ID is independent of what keypair(s) they choose to use, so keypairs can be added and rotated.
- Partial replication using tangles (merkle-trees) and [lipmaa links][lipmaa].
- Message deletion (can leave nothing, or only metadata).
- Trust based (friend to friend) with a simple invite system.

### How PZP is different from [SSB (Secure Scuttlebutt)][ssb]

- Storage is designed to not grow indefinitely. By default (of course overridable) an app's storage shouldn't go above 100MB.
- Multi device/app support from the start. Every device/app has its own keypair. They're connected together into one identity using an Account tangle. The Account tangle's root message ID is the account's identifier.
- One account or even keypair can post messages concurrently (forking) without problem. Because there aren't linear feeds, everything is in tangles, including state updates like e.g. username changes.
- Deletion is possible. The data contents of a message is separate from the message metadata, and only the metadata + hash of the data is signed.
- When messages are getting signed they get serialized according to [RFC 8785](https://tools.ietf.org/html/rfc8785).
- Easy to use invites

### How PZP is different from Nostr

- keys are not shared across devices
- sig-chains - you know if you're missing content in PZP
- trust based - invite only

## Tangles

Tangles control how messages are organised. They provide a way to group, and causally sort (partially), which is important for replication.

Basics of tangles in PZP: it's a directed acyclic graph (DAG) which aims to be as linear as possible

```mermaid
flowchart RL

E --> D --> C --> A
      D --> B --> A
```
There are 3 sorts of tangles:

- Account - a tangle which weaves (device) keys and defines capabilities / permissions of these
- Feed - a tangle where all messages are from valid devices (as defined by an Account), and scoped to a particular domain
  - e.g. all post messages from "mix"
  - e.g. all chess messages from "happy0"
- Thread - a tangle where multiple Accounts are collaborating on some state
  - e.g. all the messages making up a "10th birthday gathering"
  - e.g. all the messages in a discussion
  - e.g. all the messages in a shared shopping list

All tangles have
- a root / root message
- an ID (the id of the root message of the tangle)
- have tangle-data for causal ordering

How the tangles differ
- the Account tangle has strict validation of messages (it is only valid to write to it if you've been given permission to)
- a Feed root is deterministic! (only inputs are accountId + domain)

### Account Tangle

The account tangle starts with a message which says "This key is allowed to author messages on behalf of this account, and add further keys".

Subsequent messages in this tangle may add / remove capabilities for existing / new keys.

Messages in this tangle are verified by checking state they're extending on


### Feed Tangle

_Domain Tangle, AccountDomain Tangle_


### Thread Tangle

TODO

## Specifications

### [Messages](https://codeberg.org/pzp/pzp-db/src/branch/master/protospec.md)

### [Replication](https://codeberg.org/pzp/pzp-sync/src/branch/master/protospec.md)

### [Invites](https://codeberg.org/pzp/pzp-invite/src/branch/master/protospec.md)

### [Sets](https://codeberg.org/pzp/pzp-set/src/branch/master/protospec.md)

### [Dicts](https://codeberg.org/pzp/pzp-dict/src/branch/master/protospec.md)


## Further exploration

### Code

PZP is not ready for end users yet but it's stable enough for developers to have a fun time hacking with/on it. All the code is available [on codeberg](https://codeberg.org/pzp)

### SDK

We have [a simple SDK](https://codeberg.org/pzp/pzp-sdk) that helps you get started making PZP apps.

### Demo app

[A demo app](https://codeberg.org/pzp/zooboard) demonstrating some PZP features. Take a look at the code for inspiration. Note that you probably have to be a developer to build and use it.

[local-first]: https://www.inkandswitch.com/local-first/
[lipmaa]: https://github.com/AljoschaMeyer/bamboo#links-and-entry-verification
[zooboard]: https://codeberg.org/pzp/zooboard
[ssb]: https://scuttlebutt.nz/
