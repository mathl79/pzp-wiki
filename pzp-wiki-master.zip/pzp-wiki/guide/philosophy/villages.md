---
sidebar_position: 1
---

# Villages

> We are not trying to fix social media, we are trying to make it less central in our lives. As a replacement, we want to increase the role of villages, networks of friends, and small communities in society.

| Small (dozens) | Medium (hundreds) | Large (thousands+) |
|---|---|---|
|  | **PZP** |  |
| Telegram | Discourse | Twitter / X |
| Signal | **Mastodon** | **Mastodon** |
| WhatsApp | Discord | Facebook |
| Messenger | Slack | Instagram |
| **Briar** | Matrix | Threads |
|  | **SSB** | **SSB** |
|  | | **Bluesky** |
|  | | **Nostr** |
