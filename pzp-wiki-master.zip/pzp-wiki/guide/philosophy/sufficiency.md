---
sidebar_position: 1
---

# Sufficiency

Aim at "good enough" on all relevant criteria, instead of "best" on any one.